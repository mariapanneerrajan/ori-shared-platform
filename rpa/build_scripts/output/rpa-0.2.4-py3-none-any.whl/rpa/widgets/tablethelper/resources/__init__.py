# Resources package for TabletHelper widget
# The resources.py file is auto-generated from resources.qrc
